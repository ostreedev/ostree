This is a repository with a signed commit generated using
the following versions:

 - Fedora 32 x86_64 container image
 - ostree as of commit: a128eb551a8ffbb9c079d5b628afb907e14fd081
 - libsodium-1.0.18-3.fc32.x86_64

The goal here is to test that new or different systems can validate
this data.  For example if libsodium changes the way it parses data
in an incompatible way then this test would fail.
